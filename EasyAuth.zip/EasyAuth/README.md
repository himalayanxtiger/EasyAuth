## EasyAuth

An App Inventor 2 extension created using Rush.
